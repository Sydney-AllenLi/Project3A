export class CompMatch {
    match: Matchcomp[];
}

export class  Matchcomp {
    score: Score1;
    homeTeam1: {
        name1: string;
    };
    awayTeam1: {
        name1: string;
    };
}

export class Score1 {
    fullTime1: {
        homeTeam2: number;
        awayTeam2: number;
    };
    halfTime: {
        homeTeam2: number;
        halfTeam2: number;
    };
}
