import { Component, OnInit } from '@angular/core';
import { DataService } from '../data.service';
import { CompMatch, Matchcomp } from '../compMatch';

@Component({
  selector: 'app-comp-match',
  templateUrl: './comp-match.component.html',
  styleUrls: ['./comp-match.component.css']
})
export class CompMatchComponent implements OnInit {

  localCompMatch: CompMatch;
  match1: Matchcomp[];
  constructor(private http: DataService) { }

  ngOnInit(): void {
    this.showCompMatch();
  }

showCompMatch() {
  this.http.getCompMatch().subscribe(data3 => {
  this.localCompMatch = data3;
  this.match1 = this.localCompMatch.match;
  console.log(this.localCompMatch);
  });
 }
}
