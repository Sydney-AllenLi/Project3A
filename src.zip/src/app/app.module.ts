import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { DataService } from './data.service';
import { HttpClientModule } from '@angular/common/http';
import { TeamMatchComponent } from './team-match/team-match.component';
import { CompStandingComponent } from './comp-standing/comp-standing.component';
import { CompMatchComponent } from './comp-match/comp-match.component';

@NgModule({
  declarations: [
    AppComponent,
    TeamMatchComponent,
    CompStandingComponent,
    CompMatchComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule
  ],
  providers: [DataService],
  bootstrap: [AppComponent]
})
export class AppModule { }
