export class CompStanding {
    standings: Standing[];
}

export class Standing {
    stage: string;
    type: string;
    table: Table[];
}

export class Table {
        position: number;
        team: {
            id: number;
            name: string;
        };
        playedGames: number;
        won: number;
        draw: number;
        lost: number;
        points: number;
        goalsFor: number;
        goalsAgainst: number;
        goalDifference: number;
}

