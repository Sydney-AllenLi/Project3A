import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CompStandingComponent } from './comp-standing.component';

describe('CompStandingComponent', () => {
  let component: CompStandingComponent;
  let fixture: ComponentFixture<CompStandingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CompStandingComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CompStandingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
