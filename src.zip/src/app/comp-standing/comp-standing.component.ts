import { Component, OnInit, Input } from '@angular/core';
import { CompStanding, Standing} from '../compStanding';
import { DataService } from '../data.service';

@Component({
  selector: 'app-comp-standing',
  templateUrl: './comp-standing.component.html',
  styleUrls: ['./comp-standing.component.css']
})
export class CompStandingComponent implements OnInit {
  localStanding: CompStanding;
  standing1: Standing[];

  constructor(private http: DataService) { }

  ngOnInit(): void {
    this.showComStanding();
  }
  showComStanding() {
    this.http.getCompStanding().subscribe(data2 => {
      this.localStanding = data2;
      this.standing1 = this.localStanding.standings;
      console.log(this.localStanding);
    });
  }

}
