export class TeamMatch {
     matches: Matches[];
}

export class Matches {
    scores: Score;
    homeTeam: {
        name: string;
    };
    awayTeam: {
        name: string;
    };
}

export class Score {
    fullTime: {
        homeTeam: number;
        awayTeam: number;
    };
    halfTime: {
        homeTeam: number;
        awayTeam: number;
    };
}
