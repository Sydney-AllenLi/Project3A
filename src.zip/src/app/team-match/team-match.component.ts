import { Component, OnInit } from '@angular/core';
import { TeamMatch, Matches } from '../teamMatch';
import { DataService } from '../data.service';

@Component({
  selector: 'app-team-match',
  templateUrl: './team-match.component.html',
  styleUrls: ['./team-match.component.css']
})
export class TeamMatchComponent implements OnInit {
  localMatch: TeamMatch;
  match: Matches[];

  constructor(private http: DataService) { }

  ngOnInit(): void {
    this.showTeamMatch();
  }
  showTeamMatch() {
    this.http.getTeamMatch().subscribe(data1 => {
    this.localMatch = data1;
    this.match = this.localMatch.matches;
    console.log(this.localMatch);
     });
    }

}
