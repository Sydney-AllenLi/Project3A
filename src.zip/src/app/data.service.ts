import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { TeamMatch } from './teamMatch';
import { CompStanding } from './compStanding';
import { CompMatch } from './compMatch';

const httpOption = {
  headers: new HttpHeaders ({
'X-Auth-Token': '792c7405c9f44edf903084da60b4d93d'
  })
};
@Injectable()
export class DataService {
  teamMatchUrl = 'http://api.football-data.org/v2/teams/69/matches';
  standingUrl = 'http://api.football-data.org/v2/competitions/2021/standings';
  compMatchUrl = 'http://api.football-data.org/v2/competitions/2021/matches';
  constructor(private http: HttpClient) { }

  getTeamMatch(): Observable<TeamMatch> {
  return this.http.get<TeamMatch>(this.teamMatchUrl, httpOption);
  }

  getCompStanding(): Observable <CompStanding> {
  return this.http.get<CompStanding>(this.standingUrl, httpOption);
  }

  getCompMatch(): Observable<CompMatch> {
    return this.http.get<CompMatch>(this.compMatchUrl, httpOption);
  }
}
