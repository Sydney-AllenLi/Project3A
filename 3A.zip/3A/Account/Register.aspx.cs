﻿using Microsoft.AspNet.Identity;
using System;
using System.Linq;
using System.Web.UI;
using _3A;
using System.Configuration;
using System.Data.SqlClient;

public partial class Account_Register : Page
{
    protected void CreateUser_Click(object sender, EventArgs e)
    {
        try
        {
            string strConnection = ConfigurationManager.ConnectionStrings["StaffConnectionString"].ConnectionString;
            SqlConnection connection = new SqlConnection(strConnection);
            connection.Open();

            string insertQuery = "insert into Staff (UserName,Password,ConfirmPassword) values (@username, @password, @confirmpassword)";
            SqlCommand cmd = new SqlCommand(insertQuery, connection);

            cmd.Parameters.AddWithValue("@username", UserName.Text);
            cmd.Parameters.AddWithValue("@password", Password.Text);
            cmd.Parameters.AddWithValue("@confirmpassword", ConfirmPassword.Text);

            cmd.ExecuteNonQuery();

            connection.Close();
        }
        catch(Exception ex)
        {
            Response.Write("Error" + ex.ToString());
        }
        

    }
}