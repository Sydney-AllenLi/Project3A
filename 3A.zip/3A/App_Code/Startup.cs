﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(_3A.Startup))]
namespace _3A
{
    public partial class Startup {
        public void Configuration(IAppBuilder app) {
            ConfigureAuth(app);
        }
    }
}
