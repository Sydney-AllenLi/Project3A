﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data.SqlClient;

public partial class Staff : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
            string strConnection = ConfigurationManager.ConnectionStrings["StaffConnectionString"].ConnectionString;
            SqlConnection connection = new SqlConnection(strConnection);
            connection.Open();
        if (IsPostBack)
        {
            SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["StaffConnectionString"].ConnectionString);
            conn.Open();
            string checkuser = "select count(*) from Staff where UserName='" + TextBox1.Text + "'";
            SqlCommand cmd = new SqlCommand(checkuser, conn);
            int temp = Convert.ToInt32(cmd.ExecuteScalar().ToString());

            if (temp == 1)
            {
                Response.Write("User Name Already Exist");
            }

            conn.Close();
        }
    }
    protected void Button_Click(object sennder, EventArgs e)
    {
        try
        {
                string strConnection = ConfigurationManager.ConnectionStrings["StaffConnectionString"].ConnectionString;
                SqlConnection connection = new SqlConnection(strConnection);
                connection.Open();

                string insertQuery = "insert into Staff (UserName,Password,ConfirmPassword) values (@username, @password, @confirmpassword)";
                SqlCommand cmd = new SqlCommand(insertQuery, connection);

                cmd.Parameters.AddWithValue("@username", TextBox1.Text);
                cmd.Parameters.AddWithValue("@password", TextBox2.Text);
                cmd.Parameters.AddWithValue("@confirmpassword", TextBox3.Text);

                cmd.ExecuteNonQuery();
                Response.Write("You have successfully regist!");
                connection.Close();
        }
        catch (Exception ex)
        {
            Response.Write("Error" + ex.ToString());
        }
    }
}